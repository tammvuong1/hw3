package hw3;

/**
 * Enum class that contains the events.
 *
 * @author Tam Vuong
 * @version 9/20/24
 */
public enum BattlemintonEvent {
    GLIDER(30, true, BodyPart.ARMS, BodyPart.HEAD, BodyPart.TORSO),
    PROPELLER(90, false, BodyPart.ARMS, BodyPart.HANDS, BodyPart.HEAD,
            BodyPart.FEET, BodyPart.LEGS, BodyPart.TORSO),
    JET(120, false, BodyPart.HEAD, BodyPart.TORSO);

    private final BodyPart[] targets;
    private final ShuttlecockPart[] shuttlecockParts;
    private final int speed;

    /**
     * Constructor for BattlemintonEvent.
     *
     * @param speed      The maximum speed of the shuttlecock.
     * @param feathersOK If true, feathers can be used to score points.
     * @param targets    The body parts that can be used to score points.
     */
    BattlemintonEvent(int speed, boolean feathersOK, BodyPart... targets) {
        this.speed = speed;
        this.targets = targets;
        if (feathersOK) {
            this.shuttlecockParts = new ShuttlecockPart[] {
                    ShuttlecockPart.BASE, ShuttlecockPart.FEATHERS };
        } else {
            this.shuttlecockParts = new ShuttlecockPart[] {
                    ShuttlecockPart.BASE };
        }
    }

    /**
     * Gets the speed of the event.
     *
     * @return the speed.
     */
    public int getSpeed() {
        return speed;
    }

    /**
     * Checks if the body part is a valid scoring target.
     *
     * @param target The body part to check.
     * @return True if the body part is a valid target.
     */
    public boolean isOnTarget(BodyPart target) {
        if (target == null) {
            return false;
        }
        for (BodyPart part : targets) {
            if (part == target) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if the shuttlecock part can score on the given body part.
     *
     * @param part The part of the shuttlecock.
     * @return True if the shuttlecock part can score on the target body part.
     */
    public boolean isScoringShuttlecockPart(ShuttlecockPart part) {
        if (part == null) {
            return false;
        }
        for (ShuttlecockPart shuttlePart : shuttlecockParts) {
            if (shuttlePart == part) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if a contact of the given ShuttlecockPart on
     * the given BodyPart scores points in this BattlemintonEvent.
     *
     * @param part   The part of the shuttlecock.
     * @param target The body part being targeted.
     * @return True if the contact of the shuttlecock part on
     *         the body part scores points.
     */
    public boolean isScoringContact(ShuttlecockPart part, BodyPart target) {
        return isScoringShuttlecockPart(part) && isOnTarget(target);
    }

    /**
     * Calculates the points scored based on the shuttlecock part and target
     * body part.
     *
     * @param part   The part of the shuttlecock.
     * @param target The body part to score on.
     * @return The number of points scored.
     */
    public int points(ShuttlecockPart part, BodyPart target) {
        if (isScoringShuttlecockPart(part)) {
            return target.getPossiblePoints();
        }
        return 0;
    }
}
