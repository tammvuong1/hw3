package hw3;

/**
 * Enum class that contains the parts of the shuttlecock.
 *
 * @author Tam Vuong
 * @version 9/20/24
 */
public enum ShuttlecockPart {
    BASE,
    FEATHERS;
}
