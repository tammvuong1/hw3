package hw3;

public class BattlemintonTest {

	public static void main(String[] args) {

		BattlemintonEvent event;
		event = BattlemintonEvent.JET;

		System.out.println("\n");
		System.out.println("Testing BattlemintonEvent");
		System.out.println("   event.getSpeed(): " + event.getSpeed());
		System.out.println("   event.isScoringContact(ShuttlecockPart.BASE, BodyPart.TORSO): " +
			event.isScoringContact(ShuttlecockPart.BASE, BodyPart.TORSO));
		System.out.println("   event.isScoringContact(ShuttlecockPart.FEATHERS, BodyPart.TORSO):" +
			event.isScoringContact(ShuttlecockPart.FEATHERS, BodyPart.TORSO));
		System.out.println("   	event.isScoringContact(ShuttlecockPart.FEATHERS, BodyPart.HANDS): " +
			event.isScoringContact(ShuttlecockPart.FEATHERS, BodyPart.HANDS));

		System.out.println("\n");
		System.out.println("Testing Battle");
		Battle battle;
		battle = new Battle(BattlemintonEvent.JET, "Deadpool", "Wolverine");
		System.out.println("battle.getEvent().toString(): " + battle.getEvent().toString());
		System.out.println("battle.getPlayerWest(): " + battle.getPlayerWest());
		System.out.println("battle.getPlayerEast(): " + battle.getPlayerEast());
		battle.increaseWestScore(ShuttlecockPart.BASE, BodyPart.HEAD);
		System.out.println("battle.increaseWestScore(ShuttlecockPart.BASE, BodyPart.HEAD): " + battle.toString());
		battle.increaseEastScore(ShuttlecockPart.BASE, BodyPart.TORSO);
		System.out.println("battle.increaseEastScore(ShuttlecockPart.BASE, BodyPart.TORSO): " + battle.toString());
	}
}
