package hw3;

/**
 * Battle class that constructs the game.
 *
 * @author Tam Vuong
 * @version 9/20/24
 */
public class Battle {
    private BattlemintonEvent event;
    private String playerEast;
    private String playerWest;
    private int scoreEast;
    private int scoreWest;

    /**
     * Constructor for Battle.
     *
     * @param event The Battleminton event for this battle.
     * @param playerWest The name of the player on the west side.
     * @param playerEast The name of the player on the east side.
     */
    public Battle(BattlemintonEvent event, String playerWest,
            String playerEast) {
        this.event = event;
        this.playerWest = playerWest;
        this.playerEast = playerEast;
        this.scoreEast = 0;
        this.scoreWest = 0;
    }

    /**
     * Gets the Battleminton event for this battle.
     *
     * @return the event.
     */
    public BattlemintonEvent getEvent() {
        return event;
    }

    /**
     * Gets the east player's name.
     *
     * @return the name of the east player.
     */
    public String getPlayerEast() {
        return playerEast;
    }

    /**
     * Gets the west player's name.
     *
     * @return the name of the west player.
     */
    public String getPlayerWest() {
        return playerWest;
    }

    /**
     * Gets the east player's score.
     *
     * @return the score of the east player.
     */
    public int getScoreEast() {
        return scoreEast;
    }

    /**
     * Gets the west player's score.
     *
     * @return the score of the west player.
     */
    public int getScoreWest() {
        return scoreWest;
    }

    /**
     * Increases the score of the east player based on the ShuttlecockPart and
     * BodyPart.
     *
     * @param part The part of the shuttlecock.
     * @param target The body part being targeted.
     */
    public void increaseEastScore(ShuttlecockPart part, BodyPart target) {
        scoreEast += event.points(part, target);
    }

    /**
     * Increases the score of the west player based on the ShuttlecockPart and
     * BodyPart.
     *
     * @param part The part of the shuttlecock.
     * @param target The body part being targeted.
     */
    public void increaseWestScore(ShuttlecockPart part, BodyPart target) {
        scoreWest += event.points(part, target);
    }

    /**
     * Returns a String representation of the battle's current status, including
     * the players' names and scores.
     *
     * @return A formatted string
     */
    @Override
    public String toString() {
        return String.format("%s %d, %s %d\t", playerWest, scoreWest,
                playerEast, scoreEast);
    }
}