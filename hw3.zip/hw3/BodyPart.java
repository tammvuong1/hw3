package hw3;

/**
 * Enum class that contains the parts of the body.
 *
 * @author Tam Vuong
 * @version 9/20/24
 */
public enum BodyPart {
    ARMS(5),
    HANDS(1),
    HEAD(10),
    FEET(2),
    LEGS(3),
    TORSO(8);

    private int possiblePoints;

    /**
     * Constructs the body.
     *
     * @param possiblePoints points possible
     */
    BodyPart(int possiblePoints) {
        this.possiblePoints = possiblePoints;
    }

    public int getPossiblePoints() {
        return possiblePoints;
    }
}
